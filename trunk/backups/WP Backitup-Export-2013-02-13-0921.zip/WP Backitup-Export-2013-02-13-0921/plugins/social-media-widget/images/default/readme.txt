Credits For This Icon Set Go To:

Twitter, RSS, Reddit, YouTube: FastIcon via http://www.iconspedia.com

Facebook, Digg, MySpace: Quaqe9 via http://www.iconspedia.com

E-mail: Zige Zhao via http://www.iconspedia.com

Buzz: Iconshock via http://www.iconspedia.com


