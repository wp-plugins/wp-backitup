<script type="text/javascript">var __namespace = '<?php echo $namespace; ?>';</script>
<div class="wrap">
    <div id="wp-backitup-icon" class="icon32"><img src="<?php echo plugin_dir_url(dirname(__FILE__) ); ?>images/icon32.png" alt="WP Backitup Icon" height="32" width="32" /></div>
    <h2><?php echo $page_title; ?></h2>
    <div id="content">
        <h3><?php _e('Backup', $namespace );?></h3>
        <p><?php _e('Create a backup file of this site\'s content and settings.', $namespace ) ;?></p>
        <p><a href="#" class="backup-button button-primary"><?php _e( "Backup", $namespace ) ?></a><img class="backup-icon status-icon" src="<?php echo WPBACKITUP_URLPATH. "/images/loader.gif"; ?>" height="16" width="16" /></p>
        <h3><?php _e('Download', $namespace );?></h3>
        <p id="download-link"></p>
        <h3><?php _e('Restore', $namespace );?></h3>
        <?php global $wpdb; global $current_user; ?>
        <iframe id="upload_target" name="upload_target" src=""></iframe>
        <p><?php _e('Restore a WP Backitup zip file and overwrite this site\'s content, themes, plugins, uploads and settings.', $namespace );?></p>
        <form id="restore-form" method="post" enctype="multipart/form-data" action="<?php echo WPBACKITUP_URLPATH .'/lib/includes/restore.php'; ?>"> 
                <input type="hidden" name="db_user" value="<?php echo DB_USER; ?>" />
                <input type="hidden" name="db_name" value="<?php echo DB_NAME; ?>" />
                <input type="hidden" name="db_pass" value="<?php echo DB_PASSWORD; ?>" />
                <input type="hidden" name="db_host" value="<?php echo DB_HOST; ?>" />
                <input type="hidden" name="table_prefix" value="<?php echo $wpdb->prefix; ?>" />
                <input type="hidden" name="user_id" value="<?php echo $current_user->ID; ?>" />
                <p><input name="wpbackitup-zip" id="wpbackitup-zip" type="file" /></p> 
                <p><input type="submit" class="restore-button button-primary" name="action" value="<?php _e( "Restore", $namespace ) ?>" /><img class="restore-icon status-icon" src="<?php echo WPBACKITUP_URLPATH. "/images/loader.gif"; ?>" height="16" width="16" /></p>
            </form>
        <h3><?php _e('Status', $namespace );?></h3>
        <p><div id="status"><?php _e('Nothing to report', $namespace );?></div></p>
        <?php if (site_url() == 'http://localhost/wpbackitup') {
            echo '<p><div id="php"></div></p>'; 
        } ?>
    </div>
    <div id="sidebar">
        <form action="" method="post" id="<?php echo $namespace; ?>-form">
        <?php wp_nonce_field( $namespace . "-update-options" ); ?>
        <div class="widget">
            <h3 class="promo"><?php _e('License Key', $namespace ); ?></h3>
            <?php $license = $this->get_option( 'license_key' );
                $status = $this->get_option( 'status' );
                if( $status !== false && $status == 'valid' ) { ?>
                    <p><?php _e('Automatic updates enabled', $namespace ); ?></p>
                <?php } else { ?>
                    <p><?php _e('Activate automatic updates by entering your license key', $namespace ); ?></p>
                <?php } ?>
                <p><input type="text" name="data[license_key]" id="license_key" value="<?php esc_attr_e( $license ); ?>">
                <?php if( false !== $license ) { 
                    if( $status !== false && $status == 'valid' ) { ?>
                        <span style="color:green;"><?php _e('Active', $namespace); ?></span></p>
                        <p class="submit"><input type="submit" name="Submit" class="button-secondary" value="<?php _e( "Update", $namespace ) ?>" /></p>
                    <?php } else { ?>
                        <span style="color:red;"><?php _e('Inactive', $namespace); ?></span></p>
                        <p class="submit"><input type="submit" name="Submit" class="button-secondary" value="<?php _e( "Activate", $namespace ) ?>" /></p>
                    <?php } 
                } ?>               
        </div>
        <div class="widget">
            <h3 class="promo"><?php _e('Need Support?', $namespace ); ?></h3>
            <p><?php _e('License Key', $namespace ); ?>If you are having problems with this plugin please talk about them in the <a href="http://www.wpbackitup.com/support/">support forum</a>.</p>
            <p>You can also refer to the <a href="http://www.wpbackitup.com/documentation/">WP Backitup documentation</a>.</p>
        </div>
        <div class="widget">
            <h3 class="promo"><?php _e('Spread the Word', $namespace ); ?></h3>
            <p><a href="http://wordpress.org/extend/plugins/wp-backitup/">Rate the WP Backitup Lite 5&#9733;</a></p>
        </div>
        <div class="widget">
            <h3 class="promo">Presstrends</h3>
                <p><input type="radio" name="data[presstrends]" value="enabled" <?php if($this->get_option( 'presstrends' ) == 'enabled') echo 'checked'; ?>> <label>Enable</label></p>
                <p><input type="radio" name="data[presstrends]" value="disabled" <?php if($this->get_option( 'presstrends' ) == 'disabled') echo 'checked'; ?>> <label>Disable</label></p>
                <p>Help to improve Easy Webtrends by enabling <a href="http://www.presstrends.io" target="_blank">Presstrends</a>.</p>
                <p class="submit"><input type="submit" name="Submit" class="button-primary" value="<?php _e( "Save", $namespace ) ?>" /></p>
        </div>
        </form>
    </div>
</div>