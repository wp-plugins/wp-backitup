<?php
global $titles;
$titles = array();


array_push($titles,"Conflict between civilization and natural life");
array_push($titles,"Mockery of Religion");
array_push($titles,"Superstition");
array_push($titles,"Mississippi River");
array_push($titles,"Intellectual and Moral Education");
array_push($titles,"The Hypocrisy of Civilized Society");
array_push($titles,"Childhood");
array_push($titles,"Lies and Cons");
array_push($titles,"Superstitions and Folk Beliefs");
array_push($titles,"Parodies of Popular Romance Novels");
array_push($titles,"The Adventures of Tom Sawyer ");
array_push($titles,"Adventures of Huckleberry Finn");
array_push($titles,"The Grangerfords and the Shepherdsons");
array_push($titles,"Duke and the King");
array_push($titles,"Jim's escape");
array_push($titles,"Major Themes");
array_push($titles,"Reception");
array_push($titles,"Life in St. Petersburg");



