<?php /* Footer Banner Widgets - Used to display banners above footer widgets */ 
	echo '<div id="footer-banner-widgets" class="widget-area"><div class="wrap">';
    dynamic_sidebar( 'footer-banner' );
    echo '</div></div>';