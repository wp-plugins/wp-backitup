jQuery(document).ready(function($) { 
	$("#inner").addClass("gradient");
	$(".widgettitle").addClass("gradient");
});