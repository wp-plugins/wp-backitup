<?php
/** Start the engine */
require_once( get_template_directory() . '/lib/init.php' );
/** Child theme (do not remove) */
define( 'CHILD_THEME_NAME', 'Solas Lite' );
define( 'CHILD_THEME_URL', 'http://www.studiopress.com/themes/genesis' );

/** Add Viewport meta tag for mobile browsers */
add_action( 'genesis_meta', 'add_viewport_meta_tag' );
function add_viewport_meta_tag() {
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

/** Load custom favicon to header */
function custom_favicon_filter( $favicon_url ) {
    return get_stylesheet_directory_uri() .'/images/favicon.ico';
}
add_filter( 'genesis_pre_load_favicon', 'custom_favicon_filter' );

/** Add new image sizes **/
add_image_size('single-post', 580, 300, TRUE);
add_image_size('homepage-thumbnail', 150, 84, TRUE);

/** Add support for structural wraps */
add_theme_support( 'genesis-structural-wraps', array( 'header', 'nav', 'subnav', 'inner', 'footer-widgets', 'footer' ) );

/** Remove Custom Menu support (failure to do so will break theme) */
remove_theme_support ( 'genesis-menus' );

/** Register Theme menus */
add_theme_support ( 'genesis-menus' , array ( 
	'top' => 'Top Navigation Menu',
	'main' => 'Main Navigation Menu',
	'footer' => 'Footer Navigation Menu' 
) );

/** Load top navigation above header */
function load_top_navigation() {
	require(CHILD_DIR.'/top-navigation.php');
}
add_action( 'genesis_before_header', 'load_top_navigation' );

/** Remove description below header */
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

/** Load main navigation below header */
function load_main_navigation() {
	echo '<div id="nav"><div class="wrap">';  
	wp_nav_menu( array( 
		'sort_column' => 'menu_order', 
		'container_id' => 'main-navigation' , 
		'menu_class' => 'menu menu-main superfish',  
		'theme_location' => 'main'
	) ); 
	echo '</div></div>';
}
add_action( 'genesis_after_header', 'load_main_navigation' );

/** Load previous/next post link before title */
function genesis_post_navigation() {
	global $post;
	if ( is_single ( ) && get_post_type( $post->ID ) != 'tribe_events' ) { 
		echo '<div class="prev-next-posts"><div class="prev-post-link">';
		previous_post_link('<strong>&laquo; %link</strong>');
		echo '</div><div class="next-post-link">';
		next_post_link('<strong>%link &raquo;</strong>');
		echo '</div></div>';
	}
}
add_action( 'genesis_before_post_title', 'genesis_post_navigation');
add_action('genesis_after_post_content', 'genesis_post_navigation');

/** Load comment count in the header */
function comment_count() {
	global $post;
	if ( (is_home() || is_single() || is_archive() ) && get_post_type( $post->ID ) != 'tribe_events' ) {
		echo '<div class="comment-count"><a href="' .get_comments_link() .'">';
		comments_number();
		echo '</a></div>';
	}
}
add_action( 'genesis_before_post_title', 'comment_count');

/** Customize the post info function */
function post_info_filter($post_info) {
	if (is_single() || is_home() || is_archive()) {
		$post_info = '<p>by [post_author_posts_link]</p><p>[post_date]</p>';
		return $post_info;
	}
}
add_filter( 'genesis_post_info', 'post_info_filter' );

/** Customize the post meta function */
function post_meta_filter($post_meta) {
	if (is_single() && !is_archive) {
		$post_meta = '
			<ul>
				<li>[post_tags]</li>
				<li>[post_categories sep=", " before="Categories: "]</li>
				<li>Posted on [post_date] by [post_author_posts_link]</li>
			</ul>
		';
		return $post_meta;
	} else {
		$post_meta = '
			<ul>
				<li>[post_categories sep=", " before="Categories: "]</li>
			</ul>
		';
		return $post_meta;
	}
}
add_filter( 'genesis_post_meta', 'post_meta_filter' );

/** Modify the speak your mind text */
function custom_comment_form_args($args) {
    $args['title_reply'] = 'Leave your comment';
    return $args;
}
add_filter( 'genesis_comment_form_args', 'custom_comment_form_args' );

/** Register footer banner widgets */
genesis_register_sidebar( array(
    'id' => 'footer-banner',
    'name' => __( 'Footer Banners', 'genesis' ),
    'description' => __( 'This widgetised area is for displaying content below the content area and above the footer widgets.', 'genesis' ),
) );

/** Load footer banner widgets */
function footer_banner_widgets()  {
	require(CHILD_DIR.'/footer-banner-widgets.php');
}
add_action( 'genesis_before_footer', 'footer_banner_widgets' );

/** Add 3-column footer support in genesis */
add_theme_support( 'genesis-footer-widgets', 3);

/** Move widgets below footer banner widgets */
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

/* Load post image */
function load_post_image() {
	if ( has_post_thumbnail() && ( is_home()||is_front_page()||is_single() ) ) {
		//Get the post caption
		$pj_thumbnail_id = get_post_thumbnail_id($post->ID);
		$pj_thumbnail_image = get_posts(array('p' => $pj_thumbnail_id, 'post_type' => 'attachment', 'post_status' => 'any'));
		$caption = $pj_thumbnail_image[0]->post_excerpt;
		if ($caption == "") {
			$caption = get_the_title();
		}
		if (is_home()||is_front_page()) { 
			//Generate the image and caption (with link)
			echo '<div class="featured-image"><a href="' .get_permalink() .'" title="' .get_the_title() .'">';
			the_post_thumbnail('single-post');
			echo '</a><div class="featured-image-captian"><a href="' .get_permalink() .'" title="' .get_the_title() .'">' .$caption .'</a></div></div>';
		} else {
			//Generate the image and caption (without link)
			echo '<div class="featured-image">';
			the_post_thumbnail('single-post');
			echo '<div class="featured-image-captian">' .$caption .'</div></div>';
		}
	}
}
add_action( 'genesis_post_content', 'load_post_image', 8 );

/** Modify the Genesis content limit read more link */
function custom_read_more_link() {
    return '<p><a class="more-link" href="' . get_permalink() . '">Continue Reading</a></p>';
}
add_filter( 'excerpt_more', 'custom_read_more_link' );
add_filter( 'get_the_content_more_link', 'custom_read_more_link' );
add_filter( 'the_content_more_link', 'custom_read_more_link' );

/** Load footer navigation above footer */
function load_footer_navigation() {
	require(CHILD_DIR.'/footer-navigation.php');
}
add_action( 'genesis_before_footer', 'load_footer_navigation' );

/** Load custom footer credits */
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo '<strong>Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a href="' .get_bloginfo('url') .'">British Council ' .get_bloginfo('name') .'</a>.</strong>';
    echo '</p>The United Kingdom\'s international organisation for cultural relations and educational opportunities. A registered charity: 209131 (England and Wales) SC037733 (Scotland).</p></div>';
}
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');

/** Load custom homepage template */
function load_homepage_template() {
	if ( is_front_page() ) {
		require(CHILD_DIR.'/homepage-template.php');
	}
}
add_action( 'genesis_after_post_content', 'load_homepage_template' );

/** Load custom login page logo */
function my_login_logo() { ?>
    <style type="text/css">
        body.login div#login h1 a {
            background: url(<?php echo get_stylesheet_directory_uri(); ?>/images/site-login-logo.png) no-repeat;
			height: auto;
            margin-left: 3%;
			padding: 5% 0;
			max-width: 100%;
        }
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'my_login_logo' );

/** Load IE9 fixes */
function load_ie9_fixes() { ?>
	<!--[if gte IE 9]>
		<style type="text/css">.gradient {filter: none;}</style>
	<![endif]-->
<?php }
add_action('wp_head', 'load_ie9_fixes');

/** Load custom javascript */
function load_custom_javascript() {
	if ( !is_admin() ) {
		wp_enqueue_script('ie9_gradient_fix',  get_stylesheet_directory_uri() .'/js/ie9_gradient_fix.js', array('jquery'), '1.0', true);
	}
}
add_action('wp_enqueue_scripts', 'load_custom_javascript');

/** Custom excerpt lengths */
function custom_excerpt_length($excerpt_length = 55, $id = false, $echo = true) {
         
    $text = '';
   
          if($id) {
                $the_post = & get_post( $my_id = $id );
                $text = ($the_post->post_excerpt) ? $the_post->post_excerpt : $the_post->post_content;
          } else {
                global $post;
                $text = ($post->post_excerpt) ? $post->post_excerpt : get_the_content('');
    }
         
                $text = strip_shortcodes( $text );
                $text = apply_filters('the_content', $text);
                $text = str_replace(']]>', ']]&gt;', $text);
          $text = strip_tags($text);
       
                $excerpt_more = '<p><a class="more-link" href="' . get_permalink() . '">Continue Reading</a></p>';
                $words = preg_split("/[\n\r\t ]+/", $text, $excerpt_length + 1, PREG_SPLIT_NO_EMPTY);
                if ( count($words) > $excerpt_length ) {
                        array_pop($words);
                        $text = implode(' ', $words);
                        $text = $text . $excerpt_more;
                } else {
                        $text = implode(' ', $words);
                }
        if($echo)
  echo apply_filters('the_content', $text);
        else
        return $text;
}
 
function get_custom_excerpt($excerpt_length = 55, $id = false, $echo = false) {
	return custom_excerpt_length($excerpt_length, $id, $echo);
}

/** Load secondary sidebar after primary sidebar */
function load_secondary_sidebar() {
	if( !is_front_page() && !is_page() ) {
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-alt') ) :
		endif;
	}
}
add_action('genesis_after_sidebar_widget_area','load_secondary_sidebar');