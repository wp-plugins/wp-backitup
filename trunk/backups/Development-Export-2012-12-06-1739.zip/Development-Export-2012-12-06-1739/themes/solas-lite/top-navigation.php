<?php /* Top Navigation (Loaded above header) */
	echo '<div id="top-nav"><div class="wrap">';  
	wp_nav_menu( array( 
		'sort_column' => 'menu_order', 
		'container_id' => 'top-navigation' , 
		'menu_class' => 'menu menu-top superfish sf-js-enabled', 
		'theme_location' => 'top'
	) ); 
	echo '</div></div>';