<?php /* Footer Navigation (Loaded above footer) */
	echo '<div id="footer-navigation"><div class="wrap">';  
	wp_nav_menu( array( 
		'sort_column' => 'menu_order', 
		'container_id' => 'footer-navigation' , 
		'menu_class' => 'menu menu-footer superfish sf-js-enabled', 
		'theme_location' => 'footer'
	) ); 
	echo '</div></div>';