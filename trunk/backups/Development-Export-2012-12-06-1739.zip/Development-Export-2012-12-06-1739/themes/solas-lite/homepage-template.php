<?php /* Custom homepage template to display dynamic content on the homepage */ 

//Get current page ID for post meta data
global $wp_query;
$postid = $wp_query->post->ID;
wp_reset_query(); ?>

<div id="homepage-news" class="homepage-content-area">
	<h2 class="home-title"><?php $homepage_news_title = get_post_meta($postid, 'homepage_news_title', true);
		if ($homepage_news_title != '') {
			echo $homepage_news_title;
		} else {
			echo 'News';
		}
	?></h2>
	<?php $loop_2 = new WP_Query( 'showposts=2&orderby=date&order=DESC' ); while ($loop_2->have_posts()) : $loop_2->the_post(); ?>
			<div class="post">
				<a href="<?php the_permalink(); ?>" /><?php the_post_thumbnail( 'thumbnail', array( 'class' => 'featured-image' ) ); ?></a>
				<h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="entry-content">
					<?php custom_excerpt_length(); ?>
					<p><a class="more-link" href="<?php the_permalink(); ?>">Continue Reading</a></p>
				</div>
			</div>
			
	<?php endwhile; wp_reset_query(); ?>
	
</div>
	
<div id="homepage-events" class="homepage-content-area">
	<h2 class="home-title"><?php $homepage_events_title = get_post_meta($postid, 'homepage_events_title', true);
		if ($homepage_events_title != '') {
			echo $homepage_events_title;
		} else {
			echo 'Events';
		}
	?></h2>
	<?php $loop_3 = new WP_Query( 'showposts=2&orderby=date&order=DESC&cat=events' ); while ($loop_3->have_posts()) : $loop_3->the_post(); ?>
			<div class="post">
				<div class="homepage-thumbnail"><a href="<?php the_permalink(); ?>" /><?php the_post_thumbnail( 'thumbnail', array( 'class' => 'featured-image' ) ); ?></a></div>
				<h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="entry-content">
					<?php custom_excerpt_length(); ?>
					<p><a class="more-link" href="<?php the_permalink(); ?>">Find out more about this event</a></p>
				</div>
			</div>
			
	<?php endwhile; wp_reset_query(); ?>
</div>

<div id="homepage-featured" class="homepage-content-area">
	<h2 class="home-title"><?php $homepage_featured_title = get_post_meta($postid, 'homepage_featured_title', true);
		if ($homepage_featured_title != '') {
			echo $homepage_featured_title;
		} else {
			echo 'Featured';
		}
	?></h2>
	<?php $loop_4 = new WP_Query( 'showposts=4&orderby=date&order=DESC&cat=featured' ); while ($loop_4->have_posts()) : $loop_4->the_post(); ?>
			<div class="post">
				<div class="homepage-thumbnail"><a href="<?php the_permalink(); ?>" /><?php the_post_thumbnail( 'homepage-thumbnail', array( 'class' => 'featured-image' ) ); ?></a></div>
				<h4 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
				<div class="entry-content">
					<?php custom_excerpt_length('15'); ?>
				</div>
			</div>
			
	<?php endwhile; wp_reset_query(); ?>
</div>