<?php
/**
 * The functions that were in this file have been deprecated or moved to other files.
 *
 * @category Genesis
 * @package  Deprecated
 * @author   StudioPress
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     http://www.studiopress.com/themes/genesis
 *
 * @deprecated 1.8.0
 * @ignore
 */

_deprecated_file( __FILE__, '1.8.0', null, __( 'This file no longer needs to be included.', 'genesis' ) );